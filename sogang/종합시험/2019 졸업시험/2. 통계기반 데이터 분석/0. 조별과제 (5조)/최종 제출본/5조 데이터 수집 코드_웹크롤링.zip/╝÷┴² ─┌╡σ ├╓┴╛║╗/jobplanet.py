﻿import os.path
import ssl
import urllib.parse
import urllib.request
import time
import datetime
from bs4 import BeautifulSoup
import sys

####################################################
# 여기 설정 변경이 필요합니다.

# 쿠키를 설정합니다.
cookie = ""

# 저장 폴더 경로를 지정합니다.
save_folder = ""

#출력할 산업 군을 리스트로 입력합니다
"""
보기
industry_list = [
        100,    #서비스업
        200,    #제조/화학
        300,    #의료/제약/복지
        400,    #유통/무역/운송
        500,    #교육업
        600,    #건설업
        700,    #IT/웹/통신
        800,    #미디어/디자인
        900,    #은행/금융업
        1000    #기관/협회
    ]
"""
industry_list = [
    ]

# 지정한 숫자 이하의 회사 리뷰는 스킵합니다. 
review_min_count = 200

first_date =''
last_date =''

first_page = 0

# 여기 까지
#######################################################


first_time = 0
last_time = 0
if len(first_date) :
    first_time = time.mktime(datetime.datetime.strptime(first_date, "%Y%m%d").timetuple())
if len(last_date) :
    last_time = time.mktime(datetime.datetime.strptime(last_date, "%Y%m%d").timetuple())

if first_time > last_time :
    print("OPTION_ERROR. first_date is greater than end_date")
    sys.exit(1)
if len(industry_list) == 0 :
    print("OPTION_ERROR. industry_list is empty")
    sys.exit(1)

if not os.path.isdir(save_folder) :
    print("OPTION_ERROR. not found save folder")
    sys.exit(1)

if len(cookie) == 0 :
    print("OPTION_ERROR. cookie is empty")
    sys.exit(1)


test_loop_count=0
company_list_test_loop_count=0
list_url="https://www.jobplanet.co.kr/companies?industry_id="

def write_commend(industry_id, date, company_name, company_id, comment_id, scores, recommend_str, up_str, add_values) :
    """
    구분자 : \t
    순서 : 코멘트 아이디, 승진 기회 및 가능성, 복지 및 급여, 업무와 삶의 균형, 사내문화, 경영진, 추천, 향후기대
    name : date, cname, cid, cmid, possibiilty, pay, balance, culture, management, recommend, expect
    value :
        date : 날
        cid : int
        possibility, pay, balance, culture, management :  int (1-5)
        recommend : None, 0(추천안함), 1(추천)
        expect: None, 0(하락), 1(비슷), 2(상승/성장)

    add_values :
    #job_kind, current, area, helpful_count, is_best, subject, good, bad, hope, 
    
    """
    
    file_name = "data{}_{}.csv".format(date.split("/")[0],date.split("/")[1])
    #print(file_name)
    if not os.path.isfile(save_folder+file_name) :
        print("Create File {}{}".format(save_folder,file_name))
        f = open(save_folder+file_name, 'w',encoding='UTF-8') 
        f.write("date\tcname\tindustry_id\tcid\tcmid\tpossibility\tpay\tbalance\tculture\tmanagement\trecommend\texpect\tjob_kind\tcurrent\tarea\thelpful_count\tis_best\tsubject\tgood\tbad\thope\n")
    else :
        f = open(save_folder+file_name, 'a',encoding='UTF-8') 
    vals = [date, company_name, industry_id, company_id, comment_id]
    vals.extend(scores)

    recommend = None
    expect=None
    if recommend_str is not None :
        if recommend_str == "이 기업을 추천하지 않습니다.":
            recommend = 0
        elif recommend_str == "이 기업을 추천 합니다!":
            recommend = 1
        else :
            print("Check Recommend Invalid {}".format(recommend_str))
        
    if up_str is not None :
        if up_str == "하락" :
            expect = 0
        elif  up_str == "비슷" :
            expect = 1
        elif  up_str == "성장" :
            expect = 2
        else :
            print("Check Expect Invalid {}".format(up_str))
    vals.extend([recommend, expect])
    vals.extend(add_values)
    
    line = "\t".join(str(e) for e in vals) +"\n"
    f.write(line)
    #print(line)
    f.close()


def getCompanyHttp(url):
    scontext = ssl.SSLContext(ssl.PROTOCOL_SSLv23)
        
    #req = urllib.request.Request(test_url, data=data.encode("utf-8"))
    req = urllib.request.Request(url)
    req.add_header("user-agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36") 
    req.add_header("cookie", cookie)
    response = urllib.request.urlopen(req, context=scontext)
    result =  response.read().decode("utf-8")
    return result

def getCompanyCommends(industry_id, url, page=1, list_page=1):

    cid = url.split("/")[4]
    cname = None
    
    while True :
        page_url = url
        print()
        if page > 1 :
            if page_url[-1:] == "?" :
                page_url+="page={}".format(page)
            else :
                page_url+="?page={}".format(page)
        print(page_url)
        
        html = getCompanyHttp(page_url)
    
        soup = BeautifulSoup(html, 'html.parser')

        if  cname is None :
            cname = soup.find("h2", {"class":"tit"}).text

        commends = soup.find_all("section",  {"class":"content_ty4" })

        commend_count = (len(commends))
        print("cname={} list_page ={} page ={} recommend_count = {}".format(cname, list_page, page, commend_count))
        if commend_count == 0 :
            break

        for commend in commends :
            cmid = commend["data-content_id"]

            add_values = []
            #job_kind, current, area, helpful_count, is_best, subject, good, bad, hope, 
            var1 = commend.find("div", {"class":"content_top_ty2"})
            var2 = var1.find_all("span", {"class":"txt1"})
            if len(var2) != 3 :
                if len(var2) == 2:
                    if var2[1].text in ["현직원", "전직원"]:
                        for var3 in var2:
                            add_values.append(var3.text)
                        add_values.append("")
                    else :
                        print(var2)
                        print("Error invalid format (hotfix 3)")
                        sys.exit(1)
                else :
                    print(var2)
                    print("Error invalid format (hotfix 1)")
                    #continue
                    sys.exit(1)
            else :
                for var3 in var2:
                    add_values.append(var3.text)

            var1 = commend.find("span", {"class":"notranslate"}).text
            add_values.append(var1)

            var1 = commend.find("div", {"class":"content_body_ty1"})
            is_best = False
            var2 = var1.find("h2", {"class":"label_g"})
            if var2 is not None :
                is_best = True
            else :
                var2 = var1.find("h2", {"class":"us_label"})
            add_values.append(is_best)
            add_values.append(var2.text.strip()[4:].strip().replace("\t", " ").replace("\n"," "))
            
            var2 = var1.find("dl", {"class":"tc_list"})
            var3 = var2.find_all("dd", {"class":"df1"})
            if len(var3) != 3 :
                print(var3)
                print("Error invalid format (hotfix 2)")
                #continue
                sys.exit(1)
            for var4 in var3:
                add_values.append(var4.find("span").text.strip().replace("\t", " ").replace("\n"," "))
        
            values = []
            setdate = commend.find("span", {"class":"txt2"}).text
            settime = time.mktime(datetime.datetime.strptime(setdate, "%Y/%m/%d").timetuple())
            if first_time > 0 :
                if settime < first_time :
                    print("skip. date over. {}".format(setdate))
                    continue
            if last_time > 0 :
                if settime > last_time :
                    print("skip. yet date {}".format(setdate))
                    continue

            for pct in commend.find_all("div", {"class":"bl_score"}) :
                score=int(pct["style"].split(":")[1][:-2]) / 20
                values.append(score)
            is_up = commend.find("strong")
            recommend_str = commend.find("p",{"class":"recommend"})
            #dir(is_up)
            if is_up is not None :
                is_up = is_up.text
            if recommend_str is not None :
                recommend_str = recommend_str.text
            write_commend(industry_id, setdate, cname, cid, cmid, values, recommend_str, is_up, add_values)

        if test_loop_count > 0 and test_loop_count <= page:
            break
        page+=1
        

for industry_id in industry_list :
    industry_list_url="{}{}".format(list_url, industry_id)
    print(industry_list_url)

    page=1
    if first_page != 0 :
        page = first_page
    while True :
        if page > 1 :
            html = getCompanyHttp("{}&page={}".format(industry_list_url, page))
        else :
            html = getCompanyHttp(industry_list_url)
    
        soup = BeautifulSoup(html, 'html.parser')
        companys = soup.find_all("section",  {"class":"content_ty3" })
        
        if len(companys) == 0 :
            break
        print("")
        print("Company List. page={} count={}".format(page, len(companys)))

        is_break=False
        for company in companys :
            company_name=company.find("dt", {"class":"us_titb_l3"}).find("a").text
            print(company_name)
            
            review_count_str = company.find("a", {"class":"us_stxt_1"}).text
            review_count = int(review_count_str.split(" ")[0])
            if review_count <= review_min_count:
                print("Pass Review Count 0. {} {}".format(company_name, review_count_str))
                is_break=True
                continue
            
            company_url=company.find("a", {"class":"us_stxt_1"})["href"]
            company_url="https://www.jobplanet.co.kr{}".format(company_url)
            #print(company_url)
            getCompanyCommends(industry_id, company_url, list_page=page)
            
        if company_list_test_loop_count > 0 and company_list_test_loop_count <= page :
            break
        if is_break :
            break
        page+=1

        #test break
        #break

    
#url="https://www.jobplanet.co.kr/companies/88335/reviews/%EC%8F%98%EC%B9%B4"
#getCompanyCommends(url, page=2)
