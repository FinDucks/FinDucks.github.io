# -*- coding: utf-8 -*-

import os
import shutil
import sys

import io
import codecs
import re

path = "C:\\Users\\jin\\Documents\\data\\new\\new\\"
save_path = path + "OUT\\"

file_list = os.listdir(path)

print("save_path {}".format(save_path))
for fname in file_list :
    fpath = path + fname+ "\\"
    if not os.path.isdir(fpath) :
        continue
    if fname == "out":
        continue
    if fname == "OUT" :
        continue
    print(fpath)
    flist = os.listdir(fpath)
    for f in flist :
        
        old_file_path = fpath+f
        new_file_path = save_path+f
        print("{} {}".format(old_file_path,  new_file_path))
        bPassFline = False
        if not os.path.isfile(new_file_path) :
            bPassFline= True
        print("Add File")
        fp = open(new_file_path, "a", encoding='UTF-8') 
        fr = open(old_file_path, "r", encoding='UTF-8')
         
        line = fr.readline()
        if bPassFline :
            sp = line.strip().split("\t")
            fp.write("\t".join(sp[0:17])+"\n") 
        ppp=0
        while True:
            line = fr.readline()
            if not line: break

            """
            while hex(line.encode()[-1]) == "0xd" :
                line=line.encode()[0:-1].decode("utf-8")+fr.readline()
            #print(line)
            #print(hex(line.encode()[-1]))
            """
            sp = line.strip().split("\t")
            if not re.match("[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}",sp[0]):
                #print(line)
                continue
                sys.exit(0)
            #print(sp)
            if sp[11] == "None" :
                sp[11] = "0"
            else :
                sp[11] = "1"
            #print(sp)
            #print(sp[0:17])
            #sys.exit(0)
            newline = "\t".join(sp[0:17])+"\n"
            fp.write(newline)
            
        fr.close()
        fp.close()
